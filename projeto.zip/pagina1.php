<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <!-- essa linha abaixo é super importante pro apk, ajusta pro tamanho da tela do celular -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loja do Pedro</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <!-- chamando o firebase -->
    <script src="https://www.gstatic.com/firebasejs/10.11.1/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore-compat.js"></script>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;

            /* fundo escuro caso a imagem demore a carregar */
            background-color: #333;

            /* puxando a foto da pasta com uma mascara escura por cima */
            background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('futebol_background.png');

            /* ajustando o fundo pro celular */
            background-size: cover;
            background-position: center;
            background-attachment: fixed;

            padding: 15px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background: #fff;
            width: 100%;
            max-width: 450px;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .topo {
            background: #222;
            color: #fff;
            padding: 20px;
            text-align: center;
            border-bottom: 3px solid #3b82f6;
        }

        .topo h2 {
            font-size: 1.2rem;
        }

        .conteudo {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-size: 0.85rem;
            color: #444;
            margin-bottom: 5px;
            font-weight: 600;
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 0.95rem;
        }

        .btn {
            width: 100%;
            padding: 12px;
            background: #3b82f6;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: 0.2s;
        }

        .btn:hover {
            background: #2563eb;
        }

        .btn-voltar {
            background: #777;
        }

        .btn-voltar:hover {
            background: #555;
        }

        /* no celular é melhorr as coisas ficarem uma embaixo da outra, mas mantive lado a lado se tiver espaco */
        .row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .row>div {
            flex: 1;
            min-width: 45%;
        }

        #tela2 {
            display: none;
        }

        .foto-camisa {
            width: 150px;
            height: 150px;
            object-fit: contain;
            background: #f8f9fa;
            border: 1px dashed #aaa;
            margin: 0 auto 15px;
            display: block;
            border-radius: 8px;
        }

        .preco {
            text-align: center;
            font-size: 1.3rem;
            color: #16a34a;
            font-weight: bold;
            margin: 15px 0;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="topo">
            <h2>LOJA DE CAMISAS DO PEDRO</h2>
            <p style="font-size: 0.8rem; color: #ccc; margin-top: 5px;">Seja bem vindo</p>
        </div>

        <div class="conteudo">

            <div id="tela1">
                <p style="color: #3b82f6; font-weight: bold; text-align: center; margin-bottom: 15px;">Cadastro do
                    Cliente</p>

                <div class="form-group">
                    <label>Nome Completo:</label>
                    <input type="text" id="nome">
                </div>
                <div class="row">
                    <div class="form-group">
                        <label>CPF:</label>
                        <input type="text" id="cpf">
                    </div>
                    <div class="form-group">
                        <label>CEP:</label>
                        <input type="text" id="cep">
                    </div>
                </div>
                <div class="form-group">
                    <label>Endereço:</label>
                    <input type="text" id="endereco">
                </div>
                <div class="row">
                    <div class="form-group">
                        <label>WhatsApp:</label>
                        <input type="text" id="wpp">
                    </div>
                    <div class="form-group">
                        <label>E-mail:</label>
                        <input type="email" id="email">
                    </div>
                </div>
                <button class="btn" onclick="proximaTela()">Avançar para Produtos</button>
            </div>

            <div id="tela2">
                <p style="text-align: center; margin-bottom: 15px;">Cliente: <b id="nomeExibicao"></b></p>

                <img id="imgProduto" class="foto-camisa" src="saopaulo1.png" alt="Foto da Camisa">

                <div class="form-group">
                    <label>Escolha a Camisa:</label>
                    <select id="camisa" onchange="atualizaProduto()">
                        <option value="SPFC Home" data-valor="349.90" data-img="saopaulo1.png">São Paulo FC - 2026
                            (HOME)</option>
                        <option value="SPFC Away" data-valor="299.90" data-img="saopaulo2.png">São Paulo FC - 2026
                            (AWAY)</option>
                        <option value="Real Madrid" data-valor="289.90" data-img="realmadrid.png">Real Madrid (HOME)
                        </option>
                        <option value="Liverpool" data-valor="279.90" data-img="liverpool1.png">Liverpool (HOME)
                        </option>
                        <option value="Brasil" data-valor="399.90" data-img="brasil.png">Seleção Brasileira (COPA)
                        </option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Tamanho:</label>
                    <select id="tamanho">
                        <option value="P">P</option>
                        <option value="M">M</option>
                        <option value="G">G</option>
                        <option value="GG">GG</option>
                    </select>
                </div>

                <div class="preco">
                    R$ <span id="valorReal">349,90</span>
                </div>

                <div class="row">
                    <button class="btn btn-voltar" onclick="voltar()">Voltar</button>
                    <button class="btn" onclick="salvar()">Finalizar</button>
                </div>
            </div>

        </div>
    </div>

    <script>
        // chaves do banco
        const firebaseConfig = {
            apiKey: "AIzaSyBFBV4K0TXZ4xIXTu39i1-o1uDmmbVBa6k",
            authDomain: "lojacamisas-ffe0c.firebaseapp.com",
            projectId: "lojacamisas-ffe0c",
            storageBucket: "lojacamisas-ffe0c.firebasestorage.app",
            messagingSenderId: "429130284797",
            appId: "1:429130284797:web:79be02d312fc149aabc894"
        };

        // ligando o firebase
        firebase.initializeApp(firebaseConfig);
        const db = firebase.firestore();

        function proximaTela() {
            let nome = document.getElementById('nome').value;

            // trava pra nao deixar vazio
            if (!nome) {
                alert("Preencha o nome para continuar");
                return;
            }

            document.getElementById('nomeExibicao').innerText = nome;
            document.getElementById('tela1').style.display = 'none';
            document.getElementById('tela2').style.display = 'block';
        }

        function voltar() {
            document.getElementById('tela2').style.display = 'none';
            document.getElementById('tela1').style.display = 'block';
        }

        function atualizaProduto() {
            let select = document.getElementById('camisa');
            let opcao = select.options[select.selectedIndex];

            // puxa os valores do select
            let preco = opcao.getAttribute('data-valor');
            let img = opcao.getAttribute('data-img');

            // atualiza a tela
            document.getElementById('valorReal').innerText = preco.replace('.', ',');
            document.getElementById('imgProduto').src = img;
        }

        function salvar() {
            // junta tudo no pacote do pedido
            let pedido = {
                cliente: document.getElementById('nome').value,
                cpf: document.getElementById('cpf').value,
                cep: document.getElementById('cep').value,
                endereco: document.getElementById('endereco').value,
                whatsapp: document.getElementById('wpp').value,
                email: document.getElementById('email').value,
                camisa: document.getElementById('camisa').value,
                tamanho: document.getElementById('tamanho').value,
                valor: document.getElementById('valorReal').innerText
            };

            // envia pro banco
            db.collection("pedidos").add(pedido)
                .then(() => {
                    alert("Compra realizada com sucesso! Seu pedido já está em andamento.");
                    // da f5 na pagina pra limpar
                    window.location.reload();
                })
                .catch((erro) => {
                    alert("Deu erro ao salvar: " + erro);
                });
        }
    </script>
</body>

</html>